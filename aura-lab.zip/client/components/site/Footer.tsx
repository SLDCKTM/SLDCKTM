import { Github, Linkedin, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t">
      <div className="container py-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <p className="text-sm text-muted-foreground">© 2025 Sanjay Kumar Mahato. All rights reserved.</p>
        <div className="flex items-center gap-4">
          <a
            href="https://github.com/"
            target="_blank"
            rel="noreferrer"
            className="text-muted-foreground hover:text-foreground"
            aria-label="GitHub"
          >
            <Github />
          </a>
          <a
            href="https://linkedin.com/"
            target="_blank"
            rel="noreferrer"
            className="text-muted-foreground hover:text-foreground"
            aria-label="LinkedIn"
          >
            <Linkedin />
          </a>
          <a
            href="mailto:hello@sldckathmandu.com"
            className="text-muted-foreground hover:text-foreground"
            aria-label="Email"
          >
            <Mail />
          </a>
        </div>
      </div>
    </footer>
  );
}
