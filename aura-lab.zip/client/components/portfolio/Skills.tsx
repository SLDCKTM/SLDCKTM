const skills = [
  "React", "TypeScript", "Node.js", "Express", "Tailwind", "Vite",
  "React Query", "Zod", "PostgreSQL", "Prisma", "Three.js", "Framer Motion",
];

export function Skills() {
  return (
    <section id="skills" className="container py-20">
      <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">Skills</h2>
      <div className="mx-auto mt-8 flex max-w-3xl flex-wrap justify-center gap-3">
        {skills.map((s) => (
          <span
            key={s}
            className="rounded-full border bg-secondary px-3 py-1 text-sm text-foreground shadow-sm transition hover:shadow"
          >
            {s}
          </span>
        ))}
      </div>
    </section>
  );
}
