const items = [
  {
    role: "Senior Developer",
    org: "Freelance",
    period: "2022 — Present",
    details: "Delivering end‑to‑end web apps, from UX to deployment.",
  },
  {
    role: "Frontend Engineer",
    org: "Tech Studio",
    period: "2020 — 2022",
    details: "Built component systems and optimized performance at scale.",
  },
  {
    role: "Software Intern",
    org: "Startup Lab",
    period: "2019 — 2020",
    details: "Learned product delivery, CI/CD, and best practices.",
  },
];

export function Experience() {
  return (
    <section id="experience" className="border-y bg-muted/20">
      <div className="container py-20">
        <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">Experience</h2>
        <div className="mx-auto mt-10 max-w-3xl">
          <ol className="relative border-s border-border">
            {items.map((it, i) => (
              <li key={i} className="ms-6 py-6">
                <span className="absolute -start-2.5 mt-2.5 h-5 w-5 rounded-full border bg-background"></span>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <h3 className="font-semibold">{it.role}</h3>
                  <span className="text-xs text-muted-foreground">{it.period}</span>
                </div>
                <p className="text-sm text-muted-foreground">{it.org}</p>
                <p className="mt-2 text-sm">{it.details}</p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
