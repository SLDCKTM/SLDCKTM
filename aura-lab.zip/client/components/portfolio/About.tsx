export function About() {
  return (
    <section id="about" className="container py-20">
      <div className="grid items-center gap-10 md:grid-cols-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">About Me</h2>
          <p className="prose mt-4 text-muted-foreground">
            I’m a developer based in Kathmandu crafting scalable web apps with a focus on delightful user experience and clean, maintainable code. I enjoy working across the stack and bringing ideas to life.
          </p>
          <ul className="mt-6 space-y-2 text-sm text-muted-foreground">
            <li>• Clean, accessible UI with performance in mind</li>
            <li>• Strong engineering fundamentals and testing</li>
            <li>• Modern tooling: React, TypeScript, Vite, Tailwind</li>
          </ul>
        </div>
        <div className="relative">
          <div className="absolute -inset-8 -z-10 rounded-3xl bg-gradient-to-br from-primary/20 to-blue-500/20 blur-2xl" />
          <div className="aspect-square w-3/4 rounded-2xl bg-gradient-to-br from-primary/20 to-blue-500/20 shadow-xl backdrop-blur md:w-full" />
        </div>
      </div>
    </section>
  );
}
