import { Code2, MousePointerClick, Waves } from "lucide-react";
import { useRef } from "react";

const items = [
  {
    title: "Live Typing Hero",
    desc: "A custom typewriter effect with smooth caret and cycling roles.",
    icon: Code2,
  },
  {
    title: "Parallax Interactions",
    desc: "Cards gently move with your cursor for a tactile feel.",
    icon: MousePointerClick,
  },
  {
    title: "Animated Gradients",
    desc: "Aurora backgrounds with seamless, GPU‑accelerated animation.",
    icon: Waves,
  },
];

function useParallax() {
  const ref = useRef<HTMLDivElement>(null);
  const onMouseMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    const rotateX = (-y / rect.height) * 6;
    const rotateY = (x / rect.width) * 6;
    el.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
  };
  const onLeave = () => {
    const el = ref.current;
    if (!el) return;
    el.style.transform = "rotateX(0deg) rotateY(0deg)";
  };
  return { ref, onMouseMove, onLeave };
}

export function Projects() {
  return (
    <section id="projects" className="container py-20">
      <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">Featured Projects</h2>
      <p className="mx-auto mt-3 max-w-2xl text-center text-muted-foreground">
        A showcase of the dynamic effects powering this portfolio.
      </p>
      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((it) => (
          <ProjectCard key={it.title} {...it} />
        ))}
      </div>
    </section>
  );
}

function ProjectCard({ title, desc, icon: Icon }: { title: string; desc: string; icon: React.ElementType }) {
  const { ref, onMouseMove, onLeave } = useParallax();
  return (
    <div
      className="group relative rounded-xl border bg-card p-6 shadow-sm transition-shadow hover:shadow-xl"
      onMouseMove={onMouseMove}
      onMouseLeave={onLeave}
      style={{ perspective: 600 }}
    >
      <div ref={ref as any} className="transition-transform will-change-transform">
        <div className="absolute -inset-px rounded-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{
          background: "radial-gradient(600px circle at var(--x,50%) var(--y,50%), hsl(var(--ring)/0.15), transparent 40%)",
        }} />
        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary text-primary">
          <Icon />
        </div>
        <h3 className="mt-4 text-lg font-semibold">{title}</h3>
        <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
      </div>
    </div>
  );
}
