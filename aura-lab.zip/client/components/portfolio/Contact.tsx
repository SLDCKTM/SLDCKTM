import { useState } from "react";
import { Button } from "@/components/ui/button";

export function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio inquiry from ${name || "someone"}`);
    const body = encodeURIComponent(`${message}\n\n— ${name} (${email})`);
    window.location.href = `mailto:hello@sldckathmandu.com?subject=${subject}&body=${body}`;
  };

  return (
    <section id="contact" className="container py-20">
      <div className="mx-auto max-w-2xl">
        <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">Contact</h2>
        <p className="mt-3 text-center text-muted-foreground">Have a project in mind? Let’s build it together.</p>
        <form onSubmit={onSubmit} className="mt-8 grid gap-4">
          <div className="grid gap-1">
            <label className="text-sm" htmlFor="name">Name</label>
            <input
              id="name"
              className="h-11 rounded-md border bg-background px-3 outline-none ring-0 focus:ring-2 focus:ring-ring"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              required
            />
          </div>
          <div className="grid gap-1">
            <label className="text-sm" htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              className="h-11 rounded-md border bg-background px-3 outline-none ring-0 focus:ring-2 focus:ring-ring"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
            />
          </div>
          <div className="grid gap-1">
            <label className="text-sm" htmlFor="message">Message</label>
            <textarea
              id="message"
              className="min-h-[120px] rounded-md border bg-background p-3 outline-none ring-0 focus:ring-2 focus:ring-ring"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell me about your project..."
              required
            />
          </div>
          <div className="flex items-center justify-center">
            <Button type="submit" className="brand-gradient text-white px-8">Send Message</Button>
          </div>
        </form>
      </div>
    </section>
  );
}
