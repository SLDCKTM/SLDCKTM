import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

function useTyped(words: string[], speed = 90, pause = 1200) {
  const [index, setIndex] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);
  const word = words[index % words.length] || "";

  useEffect(() => {
    const timeout = setTimeout(() => {
      setText((t) => {
        if (!deleting) {
          const next = word.slice(0, t.length + 1);
          if (next === word) setTimeout(() => setDeleting(true), pause);
          return next;
        } else {
          const next = word.slice(0, t.length - 1);
          if (next === "") {
            setDeleting(false);
            setIndex((i) => (i + 1) % words.length);
          }
          return next;
        }
      });
    }, deleting ? Math.max(40, speed / 2) : speed);
    return () => clearTimeout(timeout);
  }, [deleting, index, pause, speed, word, words.length, text]);

  return text + (deleting ? "" : "|");
}

export function Hero() {
  const typed = useTyped([
    "Full‑Stack Developer",
    "UI/UX Enthusiast",
    "Open‑Source Contributor",
  ]);

  return (
    <section className="relative overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -inset-40 opacity-60 blur-3xl brand-gradient animate-gradient-x bg-[length:200%_200%]"></div>
      </div>
      <div className="container relative flex min-h-[70vh] flex-col items-center justify-center py-24 text-center">
        <span className="inline-flex items-center gap-2 rounded-full border bg-background/60 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
          <Sparkles className="h-4 w-4 text-primary" /> Dynamic live effects
        </span>
        <h1 className="mt-6 text-4xl font-black tracking-tight sm:text-6xl">
          Sanjay Kumar Mahato
        </h1>
        <p className="mt-3 text-lg text-muted-foreground sm:text-xl">
          Open‑Source Cont
        </p>
        <p className="prose mt-6 max-w-2xl text-balance text-muted-foreground">
          I build delightful, performant experiences with thoughtful design and robust engineering.
          This portfolio is fully customizable and production‑ready.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a href="#projects">
            <Button size="lg" className="brand-gradient text-white">
              View Projects <ArrowRight />
            </Button>
          </a>
          <a href="#contact">
            <Button size="lg" variant="outline">Contact Me</Button>
          </a>
        </div>
      </div>
    </section>
  );
}
