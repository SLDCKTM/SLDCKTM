import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container flex min-h-[60vh] flex-col items-center justify-center text-center">
        <div className="brand-gradient bg-clip-text text-transparent">
          <h1 className="text-6xl font-black tracking-tight">404</h1>
        </div>
        <p className="mt-4 text-muted-foreground">Page not found</p>
        <a href="/" className="mt-6">
          <Button className="brand-gradient text-white">Go Home</Button>
        </a>
      </main>
      <Footer />
    </div>
  );
};

export default NotFound;
